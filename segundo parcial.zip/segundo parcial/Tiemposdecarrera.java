package Modelo;

/**
 *
 * @author Bryan
 */
public class Tiemposdecarrera {
    private int id;
    private String tiempoCarrera;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getTiempoCarrera() {
        return tiempoCarrera;
    }

    public void setTiempoCarrera(String tiempoCarrera) {
        this.tiempoCarrera = tiempoCarrera;
    }

    public boolean eliminarTiempoCarrera() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    public boolean guardarTiempoCarrera() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    public boolean modificarTiempoCarrera() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
}